<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="index.php">Home</a> | <a href="insert.php">Insert New Record</a> | <a href="logout.php">Logout</a></p>
<h2>View Records</h2>

<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search by customer name here.." title="Type in a name">

<br/>
<br/>

<table id="myTable" width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
  <th><strong>S.No</strong></th>
  <th><strong>Name</strong></th>
  <th><strong>Category</strong></th>
  <th><strong>Product Name</strong></th>
  <th><strong>Total Number</strong></th>
  <th><strong>Edit</strong></th>
  <th><strong>Delete</strong></th></tr>
</thead>
<tbody>
<?php
$count=1;

$sel_query= "SELECT * from new_record ORDER BY id desc;";     //"SELECT n.name,n.tnum,c1.Categoty_Name,p1.product_name FROM new_record AS n LEFT JOIN products AS p1 ON n.product_id=p1.product_id LEFT JOIN Category AS c1 ON n.Category_ID=c1.category_id ORDER BY id desc;";

$result = mysqli_query($con,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <td align="center"><?php echo $count; ?></td>
    <td align="center"><?php echo $row["name"]; ?></td>
    <td align="center"><?php echo $row["category_id"]; ?></td>
    <td align="center"><?php echo $row["product_id"]; ?></td>
    <td align="center"><?php echo $row["tnum"]; ?></td>
    <td align="center"><a href="edit.php?id=<?php echo $row["id"]; ?>">Edit</a></td>
    <td align="center"><a href="delete.php?id=<?php echo $row["id"]; ?>">Delete</a></td>
</tr>
<?php $count++; } ?>
</tbody>
</table>

<br /><br /><br /><br />
</div>

<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</body>
</html>
