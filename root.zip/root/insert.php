<?php

 
require('db.php');
include("auth.php");

//new added for product actegory open connection
// Connect to database
$con = mysqli_connect("localhost","root","","register");
	
// mysqli_connect("servername","username","password","database_name")

// Get all the categories from category table using stored procedure
$sql1 = "CALL category()";
$all_categories = mysqli_query($con,$sql1);
mysqli_next_result($con);
// Get all the categories from products table using stored procedure
$sql2 = "CALL products()";
//"SELECT * FROM `products`";

$all_products = mysqli_query($con,$sql2);



$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$trn_date = date("Y-m-d H:i:s");
$name =$_REQUEST['name'];
$tnum = $_REQUEST['tnum'];
$submittedby = $_SESSION["username"];
$id=$_REQUEST['Category'];
$pid=$_REQUEST['Product'];

//$id = mysqli_real_escape_string($con,$_POST['Category']);
// Store the Product name in a "name" variable
//$pid = mysqli_real_escape_string($con,$_POST['Products']);


mysqli_next_result($con);
$ins_query="INSERT INTO new_record (`trn_date`,`name`,`tnum`,`submittedby`,`product_id`, `category_id`) VALUES ('$trn_date','$name','$tnum','$submittedby','$pid','$id')";
mysqli_query($con,$ins_query) or die(mysqli_error($con));
$status = "New Record Inserted Successfully.</br></br><a href='view.php'>View Inserted Record</a>";




}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert New Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="dashboard.php">Dashboard</a> | <a href="view.php">View Records</a> | <a href="logout.php">Logout</a></p>

<div>
<h1>Insert New Record</h1>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<p><input type="text" name="name" placeholder="Enter Customer Name" required /></p>

<!----- new added---------------------------------------------------->
<label>Select a Category</label>
		<select name="Category">
			<?php
				// use a while loop to fetch data
				// from the $all_categories variable
				// and individually display as an option
				while ($category = mysqli_fetch_array(
					$all_categories,MYSQLI_ASSOC)):;
			?>
				<option value="<?php echo $category["Category_ID"];
					// The value we usually set is the primary key
				?>">
					<?php echo $category["Category_Name"];
						// To show the category name to the user
					?>
				</option>
			<?php
				endwhile;
				// While loop must be terminated
			?>
		</select>

		<br/>
		<br/>

		<label>Select a Product</label>

		<select name="Product">
			<?php
				// use a while loop to fetch data
				// from the $all_categories variable
				// and individually display as an option
				while ($products = mysqli_fetch_array(
						$all_products,MYSQLI_ASSOC)):;
			?>
				<option value="<?php echo $products["product_id"];
					// The value we usually set is the primary key
				?>">
					<?php echo $products["product_name"];
						// To show the category name to the user
					?>
				</option>
			<?php
				endwhile;
				// While loop must be terminated
			?>
		</select>


<p><input type="text" name="tnum" placeholder="Enter total num of product purchased" required /></p>

<p><input name="submit" type="submit" value="Submit" /></p>
</form>
<p style="color:#FF0000;"><?php echo $status; ?></p>

<br /><br /><br /><br />
</div>
</div>
</body>
</html>
